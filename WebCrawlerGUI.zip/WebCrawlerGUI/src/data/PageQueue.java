package data;

public class PageQueue
{

}

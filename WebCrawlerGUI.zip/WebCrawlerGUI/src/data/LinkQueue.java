package data;

public class LinkQueue
{

}

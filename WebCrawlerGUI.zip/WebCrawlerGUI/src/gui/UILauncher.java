package gui;

import javafx.application.Application;

/**
 * This class will launch the web crawler GUI program.
 *
 * DO NOT ALTER THIS FILE!
 *
 * @author Josh Archer
 * @version 1.0
 */
public class UILauncher
{
    public static void main(String[] args)
    {
        Application.launch(WebCrawlerUI.class);
    }
}

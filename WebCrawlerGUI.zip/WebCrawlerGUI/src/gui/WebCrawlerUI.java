package gui;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.concurrent.ExecutorService;

/**
 * A GUI-based application that displays the results
 * of a rudimentary web crawler.
 *
 * @author Josh Archer
 * @version 1.0
 */
public class WebCrawlerUI extends Application
{
    private static final double WIN_HEIGHT = 600;
    private static final double WIN_WIDTH = 900;
    private static final double COLUMN_WIDTH = 200;
    private static final int SPACER = 10;
    private static final int BUTTON_WIDTH = 150;
    private static final int BUTTON_ROW_HEIGHT = 35;
    private static final int MAX_WORDS = 15;
    private static final int DEFAULT_FONT_SIZE = 18;

    //main layout and default font
    private GridPane grid;
    private Font labelFont = Font.font("Vani", FontWeight.NORMAL, DEFAULT_FONT_SIZE);

    //tracking runnables
    private Label analysisLabel = new Label("0 analyzers");
    private Label downloaderLabel = new Label("0 downloaders");
    private int analysisRunnables = 0;
    private int downloaderRunnables = 0;

    //widgets
    private static Text linksQueueText = new Text("Links in queue: 0");
    private static Text pagesQueueText = new Text("Pages in queue: 0");
    private static Text failedDownloadsText = new Text("Failed downloads: 0");
    private static TextField seedURL = new TextField();
    private static TextArea console = new TextArea();
    private static ListView<String> wordList = new ListView<>();

    //word frequencies
    private static Map<String, Integer> wordFrequencies = new HashMap<>();
    private static final Object LOCK = new Object();
    private static Set<String> ignoredWords = new HashSet<>();

    //TODO: The pool field should be assigned an appropriate thread pool object.
    private ExecutorService pool;

    /**
     * Prints a message to the console widget on the GUI. This should
     * be used to report successful page downloads, links visited,
     * failed downloads and other notable events as detailed in the
     * assignment description.
     * @param message the message to show on the console
     */
    public static void printToConsole(String message)
    {
        Platform.runLater(() -> console.setText(message + "\n" + console.getText()));
    }

    /**
     * Updates the size of the link queue as displayed on the GUI.
     * @param total the number of links in the link queue
     */
    public static void updateLinkTotal(int total)
    {
        Platform.runLater(() -> linksQueueText.setText("Links in queue: " + total));
    }

    /**
     * Updates the size of the page queue as displayed on the GUI.
     * @param total the number of pages in the page queue
     */
    public static void updatePageTotal(int total)
    {
        Platform.runLater(() -> pagesQueueText.setText("Pages in queue: " + total));
    }

    /**
     * Updates the number of failed downloads displayed on the GUI.
     * @param total the number of failed downloads across all jobs
     *              being executed on secondary threads
     */
    public static void updateFailedDownloads(int total)
    {
        Platform.runLater(() -> failedDownloadsText.setText("Failed downloads: " + total));
    }

    /**
     * This method can be called anywhere in the application and
     * will record a word as discovered during the web crawler
     * search. The frequency of these words will then be seen
     * on the user interface.
     *
     * @param word the word found in a page
     */
    public static void observedWord(String word)
    {
        if (word.isEmpty())
        {
            return;
        }

        synchronized (LOCK)
        {
            word = word.toLowerCase();
            if (!ignoredWords.contains(word))
            {
                if (!wordFrequencies.containsKey(word))
                {
                    wordFrequencies.put(word, 0);
                }
                wordFrequencies.put(word, wordFrequencies.get(word) + 1);
            }
        }
    }

    /**
     * This method will recalculate the frequency of words
     * discovered by the web crawler and put in a request
     * for the user interface to update all word totals.
     *
     * NOTE: THIS METHOD SHOULD ONLY BE CALLED PERIODICALLY.
     * (for example, after analyzing an entire document,
     *  rather than every word in the document)
     */
    public static void updateWordFrequencies()
    {
        synchronized (LOCK)
        {
            if (wordFrequencies.size() >= MAX_WORDS)
            {
                WordFrequency[] words = new WordFrequency[wordFrequencies.size()];
                int count = 0;
                for (String word : wordFrequencies.keySet())
                {
                    words[count] = new WordFrequency(word, wordFrequencies.get(word));
                    count++;
                }

                Arrays.sort(words);

                ObservableList<String> items = FXCollections.observableArrayList();
                for (int i = words.length - 1; i >= words.length - MAX_WORDS - 1; i--)
                {
                    items.add(words[i].word + "(" + words[i].frequency + ")");
                }
                Platform.runLater(() -> wordList.setItems(items));
            }
        }
    }

    /**
     * Generates the GUI and displays it to the user
     * @param stage the primary window for the application
     */
    @Override
    public void start(Stage stage)
    {
        loadIgnoredWords();

        stage.setScene(getScene());
        stage.setTitle("Web Crawler!");
        stage.show();
    }

    private void loadIgnoredWords()
    {
        try (Scanner reader = new Scanner(new FileInputStream("files/ignored_words.txt")))
        {
            while (reader.hasNextLine())
            {
                ignoredWords.add(reader.nextLine());
            }
        }
        catch (FileNotFoundException ex)
        {
            throw new IllegalStateException("Cannot read ignored words: " + ex.getMessage());
        }
    }

    private Scene getScene()
    {
        grid = new GridPane();
        grid.setPadding(new Insets(SPACER));

        grid.getColumnConstraints().addAll(
            new ColumnConstraints(COLUMN_WIDTH),
            new ColumnConstraints(COLUMN_WIDTH),
            new ColumnConstraints(COLUMN_WIDTH),
            new ColumnConstraints(COLUMN_WIDTH)
        );

        grid.getRowConstraints().addAll(
            new RowConstraints(BUTTON_ROW_HEIGHT),
            new RowConstraints(BUTTON_ROW_HEIGHT),
            new RowConstraints(BUTTON_ROW_HEIGHT),
                new RowConstraints(BUTTON_ROW_HEIGHT),
            new RowConstraints(WIN_HEIGHT - 5 * BUTTON_ROW_HEIGHT),
            new RowConstraints(BUTTON_ROW_HEIGHT)
        );

        grid.setVgap(SPACER);
        grid.setHgap(SPACER);

        //build controls
        newThreads();
        queueStatus();
        bottomPane();

        return new Scene(grid);
    }

    private void newThreads()
    {
        //prepare labels
        GridPane.setHalignment(analysisLabel, HPos.RIGHT);
        GridPane.setHalignment(downloaderLabel, HPos.RIGHT);
        analysisLabel.setFont(labelFont);
        downloaderLabel.setFont(labelFont);

        //get our buttons
        Button analysisButton = buildAnalysisButton();
        Button downloaderButton = buildDownloaderButton();
        Button stopButton = buildStopButton();
        Button seedButton = buildSeedButton();

        //add controls
        grid.add(analysisLabel, 0, 0);
        grid.add(analysisButton, 1, 0);
        grid.add(downloaderLabel, 0, 1);
        grid.add(downloaderButton, 1, 1);
        grid.add(seedURL, 0, 2);
        grid.add(seedButton, 1, 2);
        grid.add(stopButton, 1, 3);
    }

    private Button buildAnalysisButton()
    {
        Button analysisButton = new Button("Add Analyzer");
        analysisButton.setPrefWidth(BUTTON_WIDTH);
        analysisButton.setOnAction(event -> {
            //TODO: A new AnalysisRunnable object should be added to the thread pool here...

            analysisRunnables++;
            analysisLabel.setText(analysisRunnables + " analyzers");
        });

        return analysisButton;
    }

    private Button buildDownloaderButton()
    {
        Button downloaderButton = new Button("Add Downloader");
        downloaderButton.setPrefWidth(BUTTON_WIDTH);
        downloaderButton.setOnAction(event -> {
            //TODO: A new DownloadRunnable object should be added to the thread pool here...

            downloaderRunnables++;
            downloaderLabel.setText(downloaderRunnables + " downloaders");
        });

        return downloaderButton;
    }

    private Button buildStopButton()
    {
        Button stopButton = new Button("Stop All Runnables!");
        stopButton.setPrefWidth(BUTTON_WIDTH);
        stopButton.setOnAction(event -> {
            //TODO: Shuts down all threads in the thread pool using ExecutorService.shutdownNow()
            //TODO: A new thread pool should then be created for future user interactions

            analysisRunnables = 0;
            downloaderRunnables = 0;
            analysisLabel.setText(analysisRunnables + " analyzers");
            downloaderLabel.setText(downloaderRunnables + " downloaders");
        });

        return stopButton;
    }

    private Button buildSeedButton()
    {
        Button seedButton = new Button("Add Seed URL");
        seedButton.setPrefWidth(BUTTON_WIDTH);
        seedButton.setOnAction(event -> {
            //TODO: Add the seed url to the links queue using seedButton.getText()
        });

        return seedButton;
    }

    private void queueStatus()
    {
        setPositionAndFont(linksQueueText, 0);
        setPositionAndFont(pagesQueueText, 1);
        setPositionAndFont(failedDownloadsText, 2);
    }

    private void setPositionAndFont(Text text, int col)
    {
        grid.add(text, 2, col);
        text.setFont(labelFont);
    }

    private void bottomPane()
    {
        VBox panel = new VBox();
        setSpacing(panel);

        //console output
        grid.add(console, 0, 4, 3, 1);
        console.setPrefWidth(WIN_WIDTH);
        console.setPrefHeight(WIN_HEIGHT - 5 * BUTTON_ROW_HEIGHT);

        //word frequencies
        grid.add(wordList, 3, 4);

        //button to clear output
        Button clearButton = new Button("Clear Console");
        grid.add(clearButton, 0, 5, 3, 1);
        clearButton.setOnAction(event -> console.setText(""));
    }

    private void setSpacing(VBox panel)
    {
        panel.setAlignment(Pos.CENTER);
        panel.setSpacing(SPACER);
        panel.setPadding(new Insets(SPACER));
    }

    private static class WordFrequency implements Comparable<WordFrequency>
    {
        private String word;
        private int frequency;

        public WordFrequency(String word, int frequency)
        {
            this.word = word;
            this.frequency = frequency;
        }

        @Override
        public int compareTo(WordFrequency other)
        {
            return frequency - other.frequency;
        }

        @Override
        public String toString()
        {
            return word + " - " + frequency;
        }
    }

    @Override
    public String toString()
    {
        return "WebCrawlerUI";
    }
}

package threads;

public class AnalysisRunnable
{

}

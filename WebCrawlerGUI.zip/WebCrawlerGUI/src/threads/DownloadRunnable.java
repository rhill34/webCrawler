package threads;

public class DownloadRunnable
{

}
